/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import controller.BukuDAO;
import controller.PengembalianDAO;
import model.Buku;
import model.Pengembalian;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.util.List;

/**
 *
 * @author HP
 */



public class FrmPengembalian extends JFrame {
    private PengembalianDAO pengembalianDAO = new PengembalianDAO();
    private BukuDAO bukuDAO = new BukuDAO();
    private DefaultTableModel model;

    private JComboBox<String> cmbBuku;
    private JTextField txtTglPengembalian;
    private JButton btnSimpan, btnHapus, btnReset, btnKembali;
    private JTable tabel;
    private int selectedId = -1;

    public FrmPengembalian() {
        initComponents();
        setLocationRelativeTo(null);
        setTitle("Form Pengembalian Buku");
        tampilData();
        isiComboBuku();
    }

    private void initComponents() {
        JLabel lblBuku = new JLabel("Buku:");
        JLabel lblTgl = new JLabel("Tanggal Pengembalian:");

        cmbBuku = new JComboBox<>();
        txtTglPengembalian = new JTextField();

        btnSimpan = new JButton("Simpan");
        btnHapus = new JButton("Hapus");
        btnReset = new JButton("Reset");
        btnKembali = new JButton("Kembali");

        model = new DefaultTableModel(new String[]{"ID", "Buku", "Tgl Kembali"}, 0);
        tabel = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(tabel);

        setLayout(null);

        lblBuku.setBounds(20, 20, 150, 25);
        cmbBuku.setBounds(180, 20, 200, 25);
        lblTgl.setBounds(20, 55, 150, 25);
        txtTglPengembalian.setBounds(180, 55, 200, 25);

        btnSimpan.setBounds(400, 20, 100, 25);
        btnHapus.setBounds(400, 55, 100, 25);
        btnReset.setBounds(400, 90, 100, 25);
        btnKembali.setBounds(400, 125, 100, 25);

        scrollPane.setBounds(20, 170, 540, 200);

        add(lblBuku); add(cmbBuku);
        add(lblTgl); add(txtTglPengembalian);
        add(btnSimpan); add(btnHapus); add(btnReset); add(btnKembali);
        add(scrollPane);

        setSize(600, 430);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        btnSimpan.addActionListener(e -> simpan());
        btnHapus.addActionListener(e -> hapus());
        btnReset.addActionListener(e -> resetForm());
        btnKembali.addActionListener(e -> {
            dispose();
            new FrmMainMenu().setVisible(true);
        });

        tabel.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && tabel.getSelectedRow() != -1) {
                int row = tabel.getSelectedRow();
                selectedId = Integer.parseInt(tabel.getValueAt(row, 0).toString());
                cmbBuku.setSelectedItem(tabel.getValueAt(row, 1).toString());
                txtTglPengembalian.setText(tabel.getValueAt(row, 2).toString());
            }
        });
    }

    private void isiComboBuku() {
        cmbBuku.removeAllItems();
        List<Buku> bukuList = bukuDAO.getAllBuku();
        for (Buku b : bukuList) {
            cmbBuku.addItem(b.getJudul());
        }
    }

    private void tampilData() {
        model.setRowCount(0);
        List<Pengembalian> list = pengembalianDAO.getAllPengembalian();
        for (Pengembalian p : list) {
            model.addRow(new Object[]{
                p.getIdPengembalian(), p.getNamaBuku(), p.getTglPengembalian()
            });
        }
    }

    private void simpan() {
    String buku = cmbBuku.getSelectedItem().toString();
    String tgl = txtTglPengembalian.getText();

    if (buku == null || tgl.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Semua field harus diisi!");
        return;
    }

    try {
        // Konversi String ke java.util.Date
        java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd");
        java.util.Date utilDate = sdf.parse(tgl);

        // Isi data Pengembalian
        Pengembalian p = new Pengembalian();
        p.setNamaBuku(buku);
        p.setTglPengembalian(tgl);
        p.setTglDikembalikan(utilDate);

        // SEMENTARA kita set idPinjam = 1 dan denda = 0
        // Nanti kamu bisa buat ComboBox idPinjam juga kalau mau
        p.setIdPinjam(1); // GANTI sesuai data peminjaman yang cocok
        p.setDenda(0);

        // Simpan ke DB
        pengembalianDAO.tambahPengembalian(p);
        tampilData();
        resetForm();

        JOptionPane.showMessageDialog(this, "Data pengembalian berhasil disimpan!");

    } catch (Exception e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "Format tanggal salah (gunakan yyyy-MM-dd)!");
    }
}

    private void hapus() {
        if (selectedId != -1) {
            pengembalianDAO.hapusPengembalian(selectedId);
            tampilData();
            resetForm();
        }
    }

    private void resetForm() {
        cmbBuku.setSelectedIndex(0);
        txtTglPengembalian.setText("");
        selectedId = -1;
        tabel.clearSelection();
    }
}

