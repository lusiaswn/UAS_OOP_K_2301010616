/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import controller.PeminjamanDAO;
import controller.PengembalianDAO;
import model.Peminjaman;
import model.Pengembalian;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;
/**
 *
 * @author HP
 */



public class FrmLaporan extends JFrame {
    private JTable tabelLaporan;
    private DefaultTableModel model;
    private JButton btnKembali;

    private PeminjamanDAO peminjamanDAO = new PeminjamanDAO();
    private PengembalianDAO pengembalianDAO = new PengembalianDAO();

    public FrmLaporan() {
        initComponents();
        setLocationRelativeTo(null);
        setTitle("Laporan Transaksi Perpustakaan");
        tampilData();
    }

    private void initComponents() {
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLayout(null);

        JLabel lblJudul = new JLabel("Laporan Transaksi Peminjaman dan Pengembalian Buku");
        lblJudul.setFont(new Font("Arial", Font.BOLD, 16));
        lblJudul.setBounds(50, 10, 500, 30);
        add(lblJudul);

        model = new DefaultTableModel(new String[]{"Jenis", "ID", "Nama/Buku", "Judul Buku", "Tanggal"}, 0);
        tabelLaporan = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(tabelLaporan);
        scrollPane.setBounds(20, 60, 560, 250);
        add(scrollPane);

        btnKembali = new JButton("Kembali");
        btnKembali.setBounds(480, 320, 100, 30);
        add(btnKembali);

        btnKembali.addActionListener(e -> {
            dispose();
            new FrmMainMenu().setVisible(true);
        });

        setSize(610, 400);
    }

    private void tampilData() {
        model.setRowCount(0);

        List<Peminjaman> peminjamanList = peminjamanDAO.getAllPeminjaman();
        for (Peminjaman p : peminjamanList) {
            model.addRow(new Object[]{
                "Peminjaman",
                p.getIdPinjam(),
                p.getNamaAnggota(),
                p.getJudulBuku(),
                p.getTglPinjam()
            });
        }

        List<Pengembalian> pengembalianList = pengembalianDAO.getAllPengembalian();
        for (Pengembalian pg : pengembalianList) {
            model.addRow(new Object[]{
                "Pengembalian",
                pg.getIdPengembalian(),
                "",
                pg.getNamaBuku(),
                pg.getTglPengembalian()
            });
        }
    }
}
