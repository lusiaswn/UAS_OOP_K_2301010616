/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.sql.*;
import java.util.*;
import model.Pengembalian;
import koneksi.Koneksi;
/**
 *
 * @author HP
 */
public class PengembalianDAO {
    

    private Connection conn;

    public PengembalianDAO() {
        conn = Koneksi.getKoneksi();
    }

    public void tambahPengembalian(Pengembalian p) {
        String sql = "INSERT INTO pengembalian (id_pinjam, tgl_dikembalikan, denda) VALUES (?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, p.getIdPinjam());
            stmt.setDate(2, new java.sql.Date(p.getTglDikembalikan().getTime()));
            stmt.setInt(3, p.getDenda());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Pengembalian> getAllPengembalian() {
        List<Pengembalian> list = new ArrayList<>();
        String sql = "SELECT * FROM pengembalian";
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Pengembalian p = new Pengembalian();
                p.setIdKembali(rs.getInt("id_kembali"));
                p.setIdPinjam(rs.getInt("id_pinjam"));
                p.setTglDikembalikan(rs.getDate("tgl_dikembalikan"));
                p.setDenda(rs.getInt("denda"));
                list.add(p);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    public void hapusPengembalian(int selectedId) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
