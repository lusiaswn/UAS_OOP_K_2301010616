/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import koneksi.Koneksi;
import java.sql.Connection;
import java.sql.*;
import java.util.*;
import model.Buku;

/**
 *
 * @author HP
 */

public class BukuDAO {

    private final Connection conn;

    public BukuDAO() {
        conn = Koneksi.getKoneksi();
    }

    public void tambahBuku(Buku buku) {
        String sql = "INSERT INTO buku (judul, pengarang, tahun_terbit, status) VALUES (?, ?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, buku.getJudul());
            stmt.setString(2, buku.getPengarang());
            stmt.setString(3, buku.getTahunTerbit());
            stmt.setString(4, buku.getStatus());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateBuku(Buku buku) {
        String sql = "UPDATE buku SET judul=?, pengarang=?, tahun_terbit=?, status=? WHERE id_buku=?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, buku.getJudul());
            stmt.setString(2, buku.getPengarang());
            stmt.setString(3, buku.getTahunTerbit());
            stmt.setString(4, buku.getStatus());
            stmt.setInt(5, buku.getIdBuku());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void hapusBuku(int idBuku) {
        String sql = "DELETE FROM buku WHERE id_buku=?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idBuku);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Buku> getAllBuku() {
        List<Buku> list = new ArrayList<>();
        String sql = "SELECT * FROM buku";
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Buku buku = new Buku();
                buku.setIdBuku(rs.getInt("id_buku"));
                buku.setJudul(rs.getString("judul"));
                buku.setPengarang(rs.getString("pengarang"));
                buku.setTahunTerbit(rs.getString("tahun_terbit"));
                buku.setStatus(rs.getString("status"));
                list.add(buku);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    public Buku getBukuById(int idBuku) {
        Buku buku = null;
        String sql = "SELECT * FROM buku WHERE id_buku=?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idBuku);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                buku = new Buku();
                buku.setIdBuku(rs.getInt("id_buku"));
                buku.setJudul(rs.getString("judul"));
                buku.setPengarang(rs.getString("pengarang"));
                buku.setTahunTerbit(rs.getString("tahun_terbit"));
                buku.setStatus(rs.getString("status"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return buku;
    }
}
